import flet as ft

def main(page: ft.Page):
    page.title = "App Móvil de Patinaje"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    count = ft.Text("0", size=60, weight="bold")

    def add_click(e):
        count.value = str(int(count.value) + 1)
        page.update()

    def min_click(e):
        count.value = str(int(count.value) - 1)
        page.update()

    page.add(
        ft.Text("CONTADOR DE PATINAJE", size=30, weight="bold", color="blue"),
        ft.Row(
            [
                ft.ElevatedButton("-", on_click=min_click, bgcolor="red", color="white"),
                count,
                ft.ElevatedButton("+", on_click=add_click, bgcolor="green", color="white"),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )

# Al final de tu archivo movil.py
if __name__ == "__main__":
    # Esto fuerza a Flet a abrirse en modo web con un puerto fijo
    # lo que suele disparar el QR en la terminal automáticamente
    ft.app(target=main, view=ft.AppView.WEB_BROWSER)